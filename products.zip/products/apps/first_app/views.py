from django.shortcuts import render
#look inside models.py for people class
from .models import Product
def index(request):
    Product.objects.create(product_name="Mac Laptop", product_description="Good condition Mac book pro must be sold", product_weight="5 lbs", product_price="$2000", product_cost="$1500", product_category="Electrionics")
    product = Product.objects.all()
    for pro in product:
        print 'Product Name:', pro.product_name,
        print 'Product Description:', pro.product_description,
        print 'Product Weight:', pro.product_weight,
        print 'Product Price:', pro.product_price,
        print 'Product Cost:', pro.product_cost,
        print 'Product Category:', pro.product_category
    return render(request,"first_app/index.html")